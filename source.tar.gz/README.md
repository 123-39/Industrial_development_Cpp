VK C++ course. Homework
==============================

# Code style 
- Camle case

# Task

## Разбор xml
Реализуйте разбор xml. В результате должно получиться дерево из Node.
У каждой Node есть:
- Имя (string)
- Массив детей
- Родитель
- Аттрибуты (name - value, все string).

# Startup instructions:
~~~
$ mkdir build
$ cd build
$ cmake ..
$ make
~~~
# Running unit tests:
~~~
$ ./test/unit/tests
~~~
# Running Integration Tests:
~~~
$ ./test/integr/tests
~~~
